package sqljdbc;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;


public class HospitalMain {
	
	
	public static void main(String[] args) throws SQLException{
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("**************HOME***************");
			System.out.println(" ");
			System.out.println("Enter your choice");
			System.out.println("1. To login as Admin");
			System.out.println("2. To login as Patient");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println("***************Welcome to Admin Login***************");
				System.out.println("   ");
				System.out.println("Enter the Username");
				String username=sc.next();
				System.out.println("Enter password");
				String password=sc.next();
				if(username.equalsIgnoreCase("admin123") && password.equalsIgnoreCase("welcome@123"))
				{

			    	System.out.println("Successfully logged in");
			        System.out.println(" ");
			        while(true)
			        {
			        	System.out.println("******************MENU******************");
			    	    System.out.println(" ");
			    	    System.out.println("Enter your choice");
				        System.out.println("1. Display Record");
				        System.out.println("2. Insert new Record");
				        System.out.println("3. Update record");
				        System.out.println("4. Delete record");
				        JdbcOperations.updateRecord();
				        int op=sc.nextInt();
				        switch(op)
				        {
				        case 1:
				        	JdbcOperations.displayDoctorRecords();
				        	JdbcOperations.displayBillRecords();
				        	JdbcOperations.displayReportRecords();
				        	break;
				        	
				        case 2:
				        	JdbcOperations.addBillRecords();
				        	JdbcOperations.addDoctorRecords();
				        	break;
				        	
				        }
				    	
			        }
				}
			}
		}
		
	}

}
