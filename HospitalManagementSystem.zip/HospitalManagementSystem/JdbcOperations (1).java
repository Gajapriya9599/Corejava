package sqljdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcOperations {
	private static Connection docconnect;
	private static PreparedStatement pst;
	private static ResultSet rs;
	private static String docid;
	private static String dname;
	private static String gender;
	private static int dage;
	private static String dmail;
	private static String dphone;
	private static String dept;
	private static String pid;
	private static String pname;
	private static String pgender;
	private static String paddress;
	private static String disease;
	private static int page;
	private static String pcon;
	private static String bid;
	private static float bamt;
	
	//display doctor records
	public static void displayDoctorRecords() throws SQLException,NumberFormatException
	{
		docconnect = DatabaseConnection.getConnection();
		String docsql = "select * from doctor";
		pst = docconnect.prepareStatement(docsql);
		rs = pst.executeQuery();
		System.out.println("Doctor Id \tDoctor Name \t Gender \t Department \t Doctor'sAge \t Doctor mail \t Doctor Contact");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t\t" +rs.getString(2)+ "\t\t" +rs.getString(3)+ "\t" 
		+rs.getString(4)+ "\t" +rs.getInt(5)+ "\t" +rs.getString(6)+ "\t" +rs.getString(7));
		}
	}
	//display selected doctor records
	public static void displaySelectedDoctorRecords() throws SQLException,NumberFormatException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Doctor Id");
		docid = sc.nextLine();
		String docsql = "select * from doctor where docid = ?";
		pst = docconnect.prepareStatement(docsql);
		pst.setString(1, docid);
		rs = pst.executeQuery();
		System.out.println("Doctor Id \tDoctor Name \t Gender \t Department \t Doctor'sAge \t Doctor mail \t Doctor Contact");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t\t" +rs.getString(2)+ "\t\t" +rs.getString(3)+ "\t" 
		+rs.getString(4)+ "\t" +rs.getInt(5)+ "\t" +rs.getString(6)+ "\t" +rs.getString(7));
		}
	}
	
	//display patient records
	public static void displayPatientRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		String ptsql = "select * from patient";
		pst = docconnect.prepareStatement(ptsql);
		rs = pst.executeQuery();
		System.out.println("Patient Id \t Patient Name \t Gender \t Disaease \t Address \t Patient age \t Patient Contact");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t" +rs.getString(2)+ "\t" +rs.getString(3)+ "\t" 
		+rs.getString(4)+ "\t" +rs.getString(5)+ "\t" +rs.getInt(6)+ "\t" +rs.getString(7));
		
	}
	}
	//displaying selected patient records
	public static void displaySelectedPatientRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient Id");
		pid = sc.nextLine();
		String ptsql = "select * from patient where pid = ?";
		pst = docconnect.prepareStatement(ptsql);
		pst.setString(1, pid);
		rs = pst.executeQuery();
		System.out.println("Patient Id \t Patient Name \t Gender \t Disaease \t Address \t Patient age \t Patient Contact");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t" +rs.getString(2)+ "\t" +rs.getString(3)+ "\t" 
		+rs.getString(4)+ "\t" +rs.getString(5)+ "\t" +rs.getInt(6)+ "\t" +rs.getString(7));
		
	}
	}
	
	//display bill records
	public static void displayBillRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		String bsql = "select * from bill";
		pst = docconnect.prepareStatement(bsql);
		rs = pst.executeQuery();
		System.out.println("Bill Id \t Patient Id \t Doctor Id \t Bill amount ");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t" +rs.getString(2)+ "\t" +rs.getString(3)+ "\t" 
		+rs.getFloat(4));
		}
	}
	//displaying report
	public static void displayReportRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		String rsql = "select * from report";
		pst = docconnect.prepareStatement(rsql);
		rs = pst.executeQuery();
		System.out.println("Patient Id \t Patient Name \t Patient Age \t patient Gender \t Disease \t Doctor Id \t Bill Id \t Bill amount" );
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t" +rs.getString(2)+ "\t" +rs.getInt(3)+ "\t" +rs.getString(4)+ "\t" +rs.getString(5)+
					"\t" +rs.getString(6)+ "\t" +rs.getString(7)+ "\t" +rs.getString(8));
		}
	}
	//displaying selected bill records
	public static void displaySelectedBillRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc  = new Scanner(System.in) ;
		System.out.println("Enter the bill id");
		bid =sc.next();
		String bsql = "select * from bill where bid = ?";
		pst = docconnect.prepareStatement(bsql);
		pst.setString(1, bid);
		rs = pst.executeQuery();
		System.out.println("Bill Id \t Patient Id \t Doctor Id \t Bill amount ");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+ "\t" +rs.getString(2)+ "\t" +rs.getString(3)+ "\t" 
		+rs.getFloat(4));
		}
	}
	//adding doctor records
	public static void addDoctorRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Doctor Id");
		docid = sc.nextLine();
		System.out.println("Enter Doctor Name");
		dname = sc.next();
		System.out.println("Enter Gender");
		gender = sc.next();
		System.out.println("Enter department");
		dept = sc.next();
		System.out.println("Enter age");
		 dage= sc.nextInt();
		System.out.println("Enter contact number");
		dphone = sc.next();
		System.out.println("Enter Doctor mail");
		dmail = sc.next();
		
		
		String sql = "select * from doctor where docid = ?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, docid);
		rs = pst.executeQuery();
		if(!rs.next())
		{
			String insert  = "insert into doctor values(?,?,?,?,?,?,?)";
			pst = docconnect.prepareStatement(insert);
			pst.setString(1, docid);
			pst.setString(2, dname);
			pst.setString(3, gender);
			pst.setString(4, dept);
			pst.setInt(5, dage);
			pst.setString(6, dmail);
			pst.setString(7,dphone);
			int retval = pst.executeUpdate();
			if(retval>0)
			{
				System.out.println("Record inserted successfully");
			}
			else
			{
				System.out.println("Record is not inserted successfully");
			}
		}
		else
		{
			System.out.println("Doctor Id already exist");
		}	
	}
	//inserting patient record
	public static void addPatientRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient Id");
		pid = sc.next();
		System.out.println("Enter patient age");
		page = sc.nextInt();
		System.out.println("Enter Patient Name");
		pname = sc.next();
		System.out.println("Enter Gender");
		pgender = sc.next();
		System.out.println("Enter disease");
		disease = sc.next();
		System.out.println("Enter patient address");
		paddress = sc.next();
		/*System.out.println("Enter patient age");
		page = sc.nextInt()*/
		System.out.println("Enter patient phone phone");
		pcon = sc.next();
		
		String sql = "select * from patient where pid = ?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, pid);
		rs = pst.executeQuery();
		if(!rs.next())
		{
			String insert  = "insert into patient values(?,?,?,?,?,?,?)";
			pst = docconnect.prepareStatement(insert);
			pst.setString(1, pid);
			pst.setString(2, pname);
			pst.setString(3, pgender);
			pst.setString(4, disease);
			pst.setString(5, paddress);
			pst.setInt(6,page);
			pst.setString(7, pcon);
			
			int retval = pst.executeUpdate();
			if(retval>0)
			{
				System.out.println("Record inserted successfully");
			}
			else
			{
				System.out.println("Record is not inserted successfully");
			}
		}
		else
		{
			System.out.println("Patient  Id already exist");
		}	
	}
	public static void addBillRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter bill Id");
		bid = sc.nextLine();
		System.out.println("Enter Patient Id");
		pid = sc.nextLine();
		System.out.println("Enter doctor Id");
		docid = sc.nextLine();
		System.out.println("Enter the bill amount");
		bamt = sc.nextFloat();
		
		String sql = "select * from bill where bid = ?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, bid);
		rs = pst.executeQuery();
		if(!rs.next())
		{
			String insert  = "insert into bill values(?,?,?,?)";
			pst = docconnect.prepareStatement(insert);
			pst.setString(1, bid);
			pst.setString(2, pid);
			pst.setString(3, docid);
			pst.setFloat(4, bamt);
			int retval = pst.executeUpdate();
			if(retval>0)
			{
				System.out.println("Record inserted successfully");
			}
			else
			{
				System.out.println("Record is not inserted successfully");
			}
		}
		else
		{
			System.out.println("Bill  Id already exist");
		}	
	}
	//insertion
	public static void insertRecord() throws SQLException {
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		while(true)
		{   
	    System.out.println("Menu for Inserting record");
		System.out.println("-----------------------");
		System.out.println("Enter your choice");
		System.out.println("1. Insert record to Doctor table");
		System.out.println("2. Insert record to patient table ");
		System.out.println("3.Insert record to Bill table");
		System.out.println("Enter your choice");
		int mn = sc.nextInt();
	    switch(mn)
	    {
	    case 1:addDoctorRecords();
	    break;
	    case 2:addPatientRecords();
	    break;
	    case 3:addBillRecords();
	    break;
	    default :
	    System.out.println("Invalid option");
		}
		System.out.println("Do you want to continue Y/N");
		char ch1=sc.next().toLowerCase().charAt(0);
		if(ch1!='y')
		{
			break;
		}
		}
		
    }
	
	public static void deleteDoctorRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Doctor Id");
		docid = sc.nextLine();
		String sql = "select * from doctor where docid =?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, docid);
		rs = pst.executeQuery();
		if(rs.next())
		{
		String delete = "delete from doctor where docid = ?";
		pst =docconnect.prepareStatement(delete);
		pst.setString(1, docid);
		int delval = pst.executeUpdate();
		if(delval>0)
		{
			System.out.println("Record deleted successfully");
		}
		else
		{
			System.out.println("Record is not deleted successfully");
		}
		
		}
		else
		{
			System.out.println(docid+ "not exist in doctor table");
		}
	}
	
	//removing bill records
	public static void deleteBillRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Bill Id");
		bid = sc.nextLine();
		String sql = "select * from bill where bid =?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, bid);
		rs = pst.executeQuery();
		if(rs.next())
		{
		String delete = "delete from bill where bid = ?";
		pst =docconnect.prepareStatement(delete);
		pst.setString(1, bid);
		int delval = pst.executeUpdate();
		if(delval>0)
		{
			System.out.println("Record deleted successfully");
		}
		else
		{
			System.out.println("Record is not deleted successfully");
		}
		
		}
		else
		{
			System.out.println(bid+ "not exist in patient table");
		}
	}
    
	//removing patient records
	public static void deletePatientRecords() throws SQLException
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter patient Id");
		pid = sc.nextLine();
		String sql = "select * from patient where pid =?";
		pst = docconnect.prepareStatement(sql);
		pst.setString(1, pid);
		rs = pst.executeQuery();
		if(rs.next())
		{
		String delete = "delete from patient where pid = ?";
		pst =docconnect.prepareStatement(delete);
		pst.setString(1, pid);
		int delval = pst.executeUpdate();
		if(delval>0)
		{
			System.out.println("Record deleted successfully");
		}
		else
		{
			System.out.println("Record is not deleted successfully");
		}
		
		}
		else
		{
			System.out.println(pid+ "not exist in doctor table");
		}
	}

	//deletion menu
	public static void deleteRecord() throws SQLException 
	{
		docconnect = DatabaseConnection.getConnection();
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		    
		    System.out.println("Menu for Deleting record");
			System.out.println("-----------------------");
			System.out.println("Enter your choice");
			System.out.println("1. Delete record in doctor table");
			System.out.println("2. Delete record in patient table ");
			System.out.println("3. Delete record in bill table");
			 int ch = sc.nextInt();
			switch(ch)
			{
			case 1 : deleteDoctorRecords();
			break;
			case 2 : deletePatientRecords();
			break;
			case 3: deleteBillRecords();
			break;
			default:
				System.out.println("Invalid option");
			}
			System.out.println("Do you want to continue Y/N");
			char ch1=sc.next().toLowerCase().charAt(0);
			if(ch1!='y')
			{
				break;
			}
				
			}
	}
		
		public static void updateRecord() throws SQLException {
			docconnect=DatabaseConnection.getConnection();
			Scanner sc;
			int ch;
			while(true)
			{
			    sc =new Scanner(System.in);
			    System.out.println("Menu for Updating record");
				System.out.println("-----------------------");
				System.out.println("Enter your choice");
				System.out.println("1. Update record to Doctor table");
				System.out.println("2. Update record to Patient table ");
				System.out.println("2. Update record to bill table ");
				int choice = sc.nextInt();
				switch(choice)
				{
				case 1:
					while(true)
					{
					    System.out.println("Menu for updating Doctor record");
			            System.out.println("-----------------------");
			            System.out.println("Enter your choice");
			            System.out.println("1. To update Doctor name");
			            System.out.println("2. To update Doctor EmailId");
			            System.out.println("3. To update Doctor Phone number");
			            System.out.println("4. To update Doctor Age ");
						System.out.println("5. To update Doctor Gender ");
						System.out.println("6. To update Doctor Dept ");
			            ch= sc.nextInt();
			            switch(ch)
			            {
			            case 1:
			            	displayDoctorRecords();
						    System.out.println("Enter Doctor Name");
						    dname=sc.nextLine();
						    System.out.println("Enter Doctor id");
						    docid=sc.next();
						    String sql = "select * from Doctor where docid = ?";
						    pst=docconnect.prepareStatement(sql);
						    pst.setString(1, docid);
						    rs=pst.executeQuery();
						    if(rs.next())
						    {
							String update="update Doctor set dname= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, dname);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						        displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;
			        case 2:
			        	displayDoctorRecords();
						System.out.println("Enter Doctor id");
						docid=sc.next();
						System.out.println("Enter Doctor Emailid");
						dmail=sc.next();
						sql = "select * from Doctor where docid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, docid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Doctor set dmail= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, dmail);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						    	displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;
			        case 3:
			        	displayDoctorRecords();
						System.out.println("Enter Doctor id");
						docid=sc.next();
						System.out.println("Enter Doctor Phone Number");
						dphone=sc.next();
						sql = "select * from Doctor where docid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, docid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Doctor set  dphone= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, dphone);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						    	displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;
			        case 4:
			        	displayDoctorRecords();
						System.out.println("Enter Doctor id");
						docid=sc.next();
						System.out.println("Enter Doctor Age");
						dage=sc.nextInt();
						sql = "select * from Doctor where docid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, docid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Doctor set dage= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setInt(1, dage);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						    	displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;
			        case 5:
			        	displayDoctorRecords();
						System.out.println("Enter Doctor id");
						docid=sc.next();
						System.out.println("Enter Doctor Gender");
						gender=sc.next();
						sql = "select * from Doctor where docid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, docid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Doctor set Docgender= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, gender);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						    	displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;
					case 6:
			            	displayDoctorRecords();
						    System.out.println("Enter Doctor Department");
						    dept=sc.next();
						    System.out.println("Enter Doctor id");
						    docid=sc.next();
						    sql = "select * from Doctor where docid = ?";
						    pst=docconnect.prepareStatement(sql);
						    pst.setString(1, docid);
						    rs=pst.executeQuery();
						    if(rs.next())
						    {
							String update="update Doctor set dept= ? where docid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, dept);
							pst.setString(2, docid);
							int retval=pst.executeUpdate();
						    if(retval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Doctors Record");
						    	displayDoctorRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else 
						{
							System.out.println(docid+" not exists in database updation not possible");
						}
						break;	
			            }
						System.out.println("Do you want to continue Y/N");
						char ch1=sc.next().toLowerCase().charAt(0);
						if(ch1!='y')
						{
							System.exit(0);
						}
			        }
				case 2:
					while(true)
					{
					System.out.println("Menu for updating Patient record");
			        System.out.println("-----------------------");
			        System.out.println("Enter your choice");
			        System.out.println("1. To update Patient disease");
			        System.out.println("2. To update patient name");
			        System.out.println("3. To patient age");
			        System.out.println("4. To update patient's gender");
			        ch=sc.nextInt();
			        switch(ch)
			        {
			        case 1:
			        	displayPatientRecords();
						System.out.println("Enter Patient Id");
						pid=sc.next();
						System.out.println("Enter patient disease");
						disease=sc.nextLine();
						String sql = "select * from Patient where pid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, pid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Patient set disease= ? where pid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, disease);
							pst.setString(2, pid);
							int rval=pst.executeUpdate();
						    if(rval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Patient Record");
						    	displayPatientRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else {
							System.out.println(pid+" Already exists");
						}
						break;
			        case 2:
			        	displayPatientRecords();
						System.out.println("Enter Patient id");
						pid=sc.next();
						System.out.println("Enter Patient name");
						pname=sc.nextLine();
						sql = "select * from Patient where pid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, pid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Patient set pname= ? where pid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, pname);
							pst.setString(2, pid);
							int rval=pst.executeUpdate();
						    if(rval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Patient Record");
						    	displayPatientRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else {
							System.out.println(pid+" not exists in database updation not possible");
						}
						break;
			        case 3:
			        	displayPatientRecords();
						System.out.println("Enter Patient id");
						pid=sc.next();
						System.out.println("Enter Patient age");
						page=sc.nextInt();
						sql = "select * from Patient where pid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1,pid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Patient set page = ? where pid=?";
							pst=docconnect.prepareStatement(update);
							pst.setInt(1, page);
							pst.setString(2, pid);
							int rval=pst.executeUpdate();
						    if(rval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Patient Record");
						    	displayPatientRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else {
							System.out.println(pid+" not exists in database updation not possible");
						}
			        	break;
				case 4:
			        	displayPatientRecords();
						System.out.println("Enter Patient id");
						pid=sc.next();
						System.out.println("Enter Patient age");
						pgender=sc.next();
						sql = "select * from Patient where pid = ?";
						pst=docconnect.prepareStatement(sql);
						pst.setString(1, pid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update Patient set pgender = ? where pid=?";
							pst=docconnect.prepareStatement(update);
							pst.setString(1, pgender);
							pst.setString(2, pid);
							int rval=pst.executeUpdate();
						    if(rval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Patient Record");
						    	displayPatientRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else {
							System.out.println(pid+" not exists in database updation not possible");
						}
			        	break;		
			  default:
				  System.out.println("Invalid option");
			}
			System.out.println("Do you want to continue Y/N");
			char ch1=sc.next().toLowerCase().charAt(0);
			if(ch1!='y')
			{
				System.exit(0);
			}
					}
			case 3: 
			            displayBillRecords();
				        System.out.println("To update billamount in bill record");
					    System.out.println("Enter bill id");
						bid=sc.next();
						System.out.println("Enter Bill Amount");
						bamt=sc.nextFloat();
						String sql1 = "select * from bill where bid = ?";
						pst=docconnect.prepareStatement(sql1);
						pst.setString(1, bid);
						rs=pst.executeQuery();
						if(rs.next())
						{
							String update="update bill set billamount = ? where bid=?";
							pst=docconnect.prepareStatement(update);
							pst.setFloat(1, bamt);
							pst.setString(2, bid);
							int rval=pst.executeUpdate();
						    if(rval>0)
						    {
						    	System.out.println("Record updated successfully");
						    	System.out.println(" ");
						    	System.out.println("After Updating Patient Record");
						    	displayBillRecords();
						    }
						    else
						    {
						    	System.out.println("Record is not updated successfully");
							}
						}
						else {
							System.out.println(bid+" not exists in database updation not possible");
						}
			        	break;	
			default:
				  System.out.println("Invalid option");
			}
			System.out.println("Do you want to continue Y/N");
			char ch1=sc.next().toLowerCase().charAt(0);
			if(ch1!='y')
			{
				System.exit(0);
			}
			        	    
			}
			}
	 }
			
	    
	    

	

