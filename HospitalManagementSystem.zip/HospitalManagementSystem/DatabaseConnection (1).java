package sqljdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
	
  static Connection con = null;
  public static Connection getConnection()
  {
	  String driver = "com.mysql.cj.jdbc.Driver";
	  String url = "jdbc:mysql://localhost:3306/hospitaldatabase";
	  String un = "root";
	  String pwd = "root";
	  try
	  {
		  Class.forName(driver);
		  con = DriverManager.getConnection(url,un,pwd);
		  if(con == null)
		  {
			  System.out.println("Connection error");
		  }
		  
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  
	return con;
	  
  }
}
